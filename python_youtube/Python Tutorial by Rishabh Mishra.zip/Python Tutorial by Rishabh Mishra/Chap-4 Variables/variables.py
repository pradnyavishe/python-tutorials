#  Variables in python
a = 1  # integer number 
print(a)

b = 1.1357101 # decimal number
print(b)

c = "Madhav"  # word/sentence- use quotes
print(c) 

Rishabh = 26  # declare a varibale using varibale 
d = Rishabh 
print(d)

x = 10     # adding a number to a variable 
print(x+1)

p,q,r = 11,12,13  # assign multiple varibales
print(p,q,r) 

# ways to declare a variable name  
MyName = "Madhav" # pascal case 
myName = "Madhav" # camel case
myname = "Madhav" # flat case 
my_name = "Madhav" # snake case 

# rules to declare a varibales 
# 1. varibale name must start with: letter or _ 
_my_name = "Madhav"
print(_my_name)
# myname = "Madhav" 

# 2. Varibale name can contain: letter, numbers, underscore (_)
my_name1 = "Madhav"
r1 = 26 
_1 = 1

# 3. Variables are case sensitive 
myname = "RishabhMishra"
print(myName) 

# 4. variables names can't be a reserved word 
# for = 10  # for is a reserved word in python  
 