print("Hello World") 
#  This is how we add a comment in python

# This is a variable
a = 5
print(a) 

# This is a variable
Instructor = 'Rishabh Mishra'
print("Python by", Instructor, sep='-')

# python as a calculator
print("5+3")
print(5+3)

b = 10
c = 20
print(b+c)
print(c/b)
print(c*b)