# creat code to use in another py file 

person1 = {'name': 'Keshav', 'age': 16} 

def say_hello(name):
    return print(f"Hello {name}, Kaise ho?") 

def say_bye(name):
    return print(f"Bye {name}, takecare!")
